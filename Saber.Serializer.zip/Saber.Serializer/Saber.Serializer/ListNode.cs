﻿using System;

namespace Saber.Serializer
{
    public class ListNode
    {
        public ListNode Prev;

        public ListNode Next;

        public ListNode Rand; // произвольный элемент внутри списка

        public string Data;
    }
}
